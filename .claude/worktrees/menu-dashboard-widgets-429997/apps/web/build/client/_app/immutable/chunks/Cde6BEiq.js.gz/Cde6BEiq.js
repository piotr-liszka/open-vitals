import{x as a}from"./B15pK_uZ.js";a();
